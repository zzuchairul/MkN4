Nama: Fauzan Adithya Zuchairul Mursalin
NIM: D121201004

Ketika menjalankan program, akan ditampilkan 3 tabel, yaitu tabel dari bracket method (Bisection), Newton-Raphson method, dan Secant method. Tabel tersebut merupakan hasil perhitungan untuk mencari nilai akar.